package it.davidecompagni.meteoapp;

public class Risposta {
    private String api = null;
    private int code;
    private String unixTime = null;
    private String citta = null;
    private String tempo = null;
    private Double temperatra = null;
    private Double umidita = null;
    private Double vento = null;

    public Risposta(String api, int code, String unixTime, String citta, String tempo, Double temperatra, Double umidita, Double vento) {
        this.api = api;
        this.code = code;
        this.unixTime = unixTime;
        this.citta = citta;
        this.tempo = tempo;
        this.temperatra = temperatra;
        this.umidita = umidita;
        this.vento = vento;
    }

    public String getApi() {
        return api;
    }
    public void setApi(String api) {
        this.api = api;
    }
    public int getCode() {
        return code;
    }
    public void setCode(int code) {
        this.code = code;
    }
    public String getUnixTime() {
        return unixTime;
    }
    public void setUnixTime(String unixTime) {
        this.unixTime = unixTime;
    }
    public String getCitta() {
        return citta;
    }
    public void setCitta(String citta) {
        this.citta = citta;
    }
    public String getTempo() {
        return tempo;
    }
    public void setTempo(String tempo) {
        this.tempo = tempo;
    }
    public Double getTemperatra() {
        return temperatra;
    }
    public void setTemperatra(Double temperatra) {
        this.temperatra = temperatra;
    }
    public Double getUmidita() {
        return umidita;
    }
    public void setUmidita(Double umidita) {
        this.umidita = umidita;
    }
    public Double getVento() {
        return vento;
    }
    public void setVento(Double vento) {
        this.vento = vento;
    }
}
