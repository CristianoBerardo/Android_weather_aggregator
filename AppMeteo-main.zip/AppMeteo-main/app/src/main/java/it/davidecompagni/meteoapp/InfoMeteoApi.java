package it.davidecompagni.meteoapp;

public class InfoMeteoApi {
}
