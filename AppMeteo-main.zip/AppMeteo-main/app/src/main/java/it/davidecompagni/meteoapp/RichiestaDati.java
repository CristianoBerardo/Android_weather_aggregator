package it.davidecompagni.meteoapp;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.loader.content.AsyncTaskLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Set;

public class RichiestaDati extends AsyncTask {

    private final String ws = "http://davidecompagni.tk"; // indirizzo provvisorio
    private MainActivity m;

    public RichiestaDati(MainActivity m) {this.m = m; }

    @Override
    protected Object doInBackground(Object[] objects) {
        long inizio, fine;
        inizio = System.currentTimeMillis();

        String luogo = null, data = null, orario = null;
        double lat = 99999, lon = 99999; // valore improponibile di controllo

        if(objects[0] instanceof String){ // caso in cui ricerco una città per nome
            luogo = (String) objects[0];
            data = (String)objects[1];
            orario = (String)objects[2];
        }else { // caso in cui ricevo latitudine e longitudine
            lat = (double) objects[0];
            lon = (double) objects[1];
            data = (String) objects[2];
            orario = (String) objects[3];
        }

        String unixDate;

        //converto la data e ora in unix time
        if(data != null && orario != null){
            String [] temp = data.split("/");

            int giorno = Integer.parseInt(temp[0]);
            int mese =  Integer.parseInt(temp[1]);
            int anno =  Integer.parseInt(temp[2]);

            temp = orario.split(":");
            int ora = Integer.parseInt(temp[0]);
            int minuto =  Integer.parseInt(temp[1]);

            GregorianCalendar c = new GregorianCalendar();

            c.set(anno,mese-1,giorno,ora,minuto);

            unixDate = String.valueOf((c.getTimeInMillis()/1000));

            Log.d("unixTime", "giorno " + giorno + " mese " + mese + " anno " + anno);
            Log.d("unixTime", "ora " + ora + " minuto " + minuto);

            Log.d("unixTime", unixDate);
        }else{
            unixDate = "current";
        }

        Log.d("unixTime", "Unix date: " + unixDate);
        BufferedReader reader = null;
        String risposta = "";

        try {
            URL chiamata = null;

            if (luogo != null) {
                luogo = luogo.replaceAll(" ","+");
                chiamata = new URL(ws + "?name=" + luogo + "&time=" + unixDate);
            } else if (lat != 99999 & lon != 99999) {
                chiamata = new URL(ws + "?lat=" + lat + "&lon=" + lon + "&time=" + unixDate);
            } else {
                Log.e("webservice", "impossibile determinare il luogo");
            }

            String line = null;

            if (chiamata != null) {

                reader = new BufferedReader(new InputStreamReader(chiamata.openStream()));
                Log.d("webservice", "chiamata al webservice: " + ws);

                while ((line = reader.readLine()) != null) {
                    risposta += line;
                }
            } else {
                Log.d("webservice", "doInBackground: chiamata = null -> rifaccio la connessione");
            }

        }catch (Exception e) {
            Log.e("webservice", "errore durante la connessione con il webservice", e);
        }

        fine = System.currentTimeMillis();
        Log.e("TAG", "doInBackground FINE in: " + (fine - inizio) + " secondi",  null );

        return risposta; // -> ritorna al onPostExecute
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        long inizio, fine;

        inizio = System.currentTimeMillis();

        if (o == null || o.equals("")){
            m.fineScaricamentoFile(null);
        }else{

            try{
                Log.d("webservice", "Eseguo il parsing: ");
                String json = (String) o;
                Log.d("rispostaWS",json);

                JSONObject reader = new JSONObject(json);
                JSONArray arrayAPI = reader.getJSONArray("ris");
                JSONObject temp = null;

                Risposta[]risp = new Risposta[3];
                Log.d("webservice", "lunghezza array:  " + arrayAPI.length());

                for(int i = 0 ; i < arrayAPI.length();i++){
                    try {
                        temp = arrayAPI.getJSONObject(i);

                        if(temp.getInt("code")!= 200){

                            Log.e("webservice","Errore nella risposta del ws, cod:"+
                                    temp.getInt("code") + " " + temp.getString("error"));
                            risp[i] = null;
                            continue; // ritorna alla condizione del ciclo
                        }

                        risp[i] = new Risposta( // quoalora mancasse un parametro viene assegnato null;

                                    temp.getString("API"),
                                    temp.getInt("code"),
                                    temp.getString("timestamp"),
                                    temp.getString("nome"),
                                    temp.getString("tempo"),
                                    temp.getDouble("temperatura"),
                                    (!temp.isNull("umidita")) ? temp.getDouble("umidita") : null ,
                                    temp.getDouble("vento")

                                );

                    }catch (Exception e){
                        Log.e("webservice", "Errore durante il parsing",e);
                    }

                }
                Log.d("webservice", "fine del parsing: ");
                m.fineScaricamentoFile(risp);   //ritorno l'oggetto al main e lui lo puo elaborare quando vuole, nel nostro caso subito

            }catch (Exception e){
                Log.e("webservice", "Errore durante il parsiong 2", e);
            }
        }

        fine = System.currentTimeMillis();
        Log.e("TAG", "doInBackground FINE" + (fine - inizio) ,  null );
    }
}
