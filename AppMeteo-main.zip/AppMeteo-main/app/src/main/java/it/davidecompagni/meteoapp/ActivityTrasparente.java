package it.davidecompagni.meteoapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityTrasparente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aggiornamento_dati);

    }
}
