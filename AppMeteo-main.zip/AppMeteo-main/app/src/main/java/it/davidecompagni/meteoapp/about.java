package it.davidecompagni.meteoapp;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class about extends AppCompatActivity {
    AppCompatButton button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

        button = (AppCompatButton) findViewById(R.id.backAbout);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                about.this.finish();
            }
        });

    }
}
