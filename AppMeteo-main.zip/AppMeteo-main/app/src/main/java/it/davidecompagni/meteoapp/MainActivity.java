package it.davidecompagni.meteoapp;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private TextView date;
    private SearchView citta;
    private DrawerLayout dw;
    private NavigationView nav;

    private static String nomeCittaRicercata;
    private static String dataInserita;
    private static String oraInserita;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        nav = findViewById(R.id.navigation);
        nav.setNavigationItemSelectedListener(this);
        nav.bringToFront();

        dw = findViewById(R.id.drawerLayout);

        date = (Button) findViewById(R.id.date);
        citta = (SearchView) findViewById(R.id.cerca);
        progressBar = (ProgressBar)findViewById(R.id.progressbar);

        date.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                android.app.DialogFragment dialogfragment = new DataPicker();
                dialogfragment.show(getFragmentManager(), "Data");

            }
        });

        citta.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                nomeCittaRicercata = String.valueOf(citta.getQuery());

                // inizio ricerca città dopo inserimento nell SearchView

                if(nomeCittaRicercata.equals("") || nomeCittaRicercata == null){ return; }

                RichiestaDati richiestaDati = new RichiestaDati(MainActivity.this);
                progressBarOn();
                richiestaDati.execute(nomeCittaRicercata, dataInserita, oraInserita);
            }

        });

        //all'apertura dell'applicazione aggiorno i dati con la posizione corrente
        richiestaPosizioneAttuale();
    }

    // funzione che fa una richiesta utilizzando le coordinate gps
    private void richiestaPosizioneAttuale(){

        //mostro la progressBar per avvisare che c'è uno scambio in corso di dati
        progressBarOn();

        LocationManager locationManager;
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        LocationListener locationListener = new LocationListener() {

            @Override
            public void onLocationChanged(@NonNull Location location) {

                RichiestaDati richiestaDati = new RichiestaDati(MainActivity.this);
                richiestaDati.execute(location.getLatitude(), location.getLongitude(), null, null);

            }

            @Override
            public void onProviderDisabled(String provider) {
                Log.d("Latitude","disable");
            }

            @Override
            public void onProviderEnabled(String provider) {
                Log.d("Latitude","enable");
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                Log.d("Latitude","status");
            }

        };

        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

            Intent gpsOptionsIntent = new Intent(
                    android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(gpsOptionsIntent);

        } else if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},44);

        }

        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER,locationListener,null);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    // case AGGIORNA è il bottone nella toolbar a destra nella home
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                    dw.openDrawer(Gravity.LEFT);
                break;

            case R.id.posione:
                    richiestaPosizioneAttuale();
                break;
        }

        return true;
    }

    public void fineScaricamentoFile(Risposta [] info){

        //qui si aggiornano le caselle del meteo
        if (info != null){
            aggiornaDatiCasella1(info[0].getCitta(),info[0].getTemperatra(),info[0].getUmidita(),info[0].getVento(),info[0].getTempo());
            aggiornaDatiCasella2(info[1].getCitta(),info[1].getTemperatra(),info[1].getUmidita(),info[1].getVento(),info[1].getTempo());
            aggiornaDatiCasella3(info[2].getCitta(),info[2].getTemperatra(),info[2].getUmidita(),info[2].getVento(),info[2].getTempo());
        }

        //dopo aver aggiornato le caselle nascondo la progress bar
        progressBarOff();
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                    dw.openDrawer(Gravity.LEFT);
                break;

            case R.id.descrizione:
                    startActivity( new Intent(this,nav.class));
                break;

            case R.id.about:
                    startActivity( new Intent(this,about.class));
                break;
        }

        return true;
    }

    public static class DataPicker extends DialogFragment implements DatePickerDialog.OnDateSetListener{

        @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState){

            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datepickerdialog = new DatePickerDialog(
                    getActivity(),
                    AlertDialog.THEME_HOLO_LIGHT,
                    this,year,month,day);

            return datepickerdialog;
        }

        public void onDateSet(DatePicker view, int year, int month, int day){

            TextView textview = (TextView)getActivity().findViewById(R.id.date);
            dataInserita = day + "/" + (month+1) + "/" + year;

            textview.setText(dataInserita);

            android.app.DialogFragment dialogfragment = new TimePicker();
            dialogfragment.show(getFragmentManager(), "Ora");
        }
    }

    public static class TimePicker extends DialogFragment implements TimePickerDialog.OnTimeSetListener{

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            final Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minutes = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(getActivity(), AlertDialog.THEME_HOLO_LIGHT,
                                                this, hour, minutes, true);

            return timePickerDialog;
        }

        @Override
        public void onTimeSet(android.widget.TimePicker timePicker, int min, int ore) {

            TextView textview = (TextView)getActivity().findViewById(R.id.date);
            String s = (String) textview.getText();

            oraInserita = min + ":" + ore;
            s += "\n" + min + ":" + ore;

            textview.setText(s);
        }
    }

    public void aggiornaDatiCasella1(String citta, Double temperatura, Double umidita, Double velocitaVento,String tempo){

        TextView casellaCitta1 = (TextView) findViewById(R.id.cittaCasella1);
        TextView gradi1 = (TextView) findViewById(R.id.gradiCasella1);
        TextView umidita1 = (TextView) findViewById(R.id.umiditaCasella1);
        TextView vento1 = (TextView) findViewById(R.id.vento1);
        ImageView icona1 = (ImageView) findViewById(R.id.icona);

        casellaCitta1.setText(citta != null ? citta : "-");
        gradi1.setText(temperatura != null ? temperatura + "°C" : "-");
        umidita1.setText(umidita != null ? umidita + "%" : "- %");
        vento1.setText(velocitaVento  != null ? velocitaVento + " Km/h " : "-");
        icona1.setBackgroundResource(getImage(tempo));
    }

    public void aggiornaDatiCasella2(String citta, Double temperatura, Double umidita, Double velocitaVento,String tempo){

        TextView casellaCitta2 = (TextView) findViewById(R.id.cittaCasella2);
        TextView gradi2 = (TextView) findViewById(R.id.gradiCasella2);
        TextView umidita2 = (TextView) findViewById(R.id.umiditaCasella2);
        TextView vento2 = (TextView) findViewById(R.id.vento2);
        ImageView icona2 = (ImageView) findViewById(R.id.icona2);

        casellaCitta2.setText(citta != null ? citta : "-");
        gradi2.setText(temperatura != null ? temperatura + "°C" : "-");
        umidita2.setText(umidita != null ? umidita + "%" : "- %");
        vento2.setText(velocitaVento  != null ? velocitaVento + " Km/h " : "-");
        icona2.setBackgroundResource(getImage(tempo));
    }

    public void aggiornaDatiCasella3(String citta, Double temperatura, Double umidita, Double velocitaVento,String tempo){
        TextView casellaCitta3 = (TextView) findViewById(R.id.cittaCasella3);
        TextView gradi3 = (TextView) findViewById(R.id.gradiCasella3);
        TextView umidita3 = (TextView) findViewById(R.id.umiditaCasella3);
        TextView vento3 = (TextView) findViewById(R.id.vento3);
        ImageView icona3 = (ImageView) findViewById(R.id.icona3);

        casellaCitta3.setText(citta != null ? citta : "-");
        gradi3.setText(temperatura != null ? temperatura + "°C" : "-");
        umidita3.setText(umidita != null ? umidita + "%" : "- %");
        vento3.setText(velocitaVento  != null ? velocitaVento + " Km/h " : "-");
        icona3.setBackgroundResource(getImage(tempo));
    }

    public int getImage(String prev) {

        switch (prev.toLowerCase()){

            case "sunny":
            case "clear":
                return R.drawable.img113;
            case "partly cloudy":
                return R.drawable.img116;
            case "cloudy":
            case "overcast":
                return R.drawable.img119;
            case "mist":
            case "smoke":
            case "haze":
            case "dust":
            case "fog":
            case "sand":
                return R.drawable.img248;
            case "patchy rain possible":
            case "patchy snow possible":
            case "patchy sleet possible":
            case "patchy light drizzle":
            case "light drizzle":
            case "patchy light rain":
            case "light rain":
            case "moderate rain":
            case "heavy rain":
            case "drizzle":
            case "rain":
                return R.drawable.img296;
            case "patchy light rain with thunder":
            case "moderate or heavy rain with thunder":
            case "patchy light snow with thunder" :
            case "moderate or heavy snow with thunder":
            case "thunderstorm":
                return R.drawable.img389;
            case "snow":
            case "light sleet":
            case "Moderate or heavy sleet":
            case "Patchy light snow":
            case "Light snow":
            case "Patchy moderate snow":
            case "Moderate snow":
            case "Patchy heavy snow":
            case "Heavy snow":
            case "Ice pellets":
            case "Light rain shower":
            case "moderate or heavy rain shower":
            case "Torrential rain shower":
            case "Light sleet showers":
            case "Moderate or heavy sleet showers":
            case "Light snow showers":
            case "Moderate or heavy snow showers":
            case "Light showers of ice pellets":
            case "Moderate or heavy showers of ice pellets":
                return R.drawable.img338;
            default:
                return R.drawable.img119;
        }
    }

    private void progressBarOn(){

        Log.d("progressBar","progressBar visibile");

        LinearLayout meteo1 = findViewById(R.id.meteo1);
        LinearLayout meteo2 = findViewById(R.id.meteo2);
        LinearLayout meteo3 = findViewById(R.id.meteo3);

        meteo1.setVisibility(View.GONE);
        meteo2.setVisibility(View.GONE);
        meteo3.setVisibility(View.GONE);

        progressBar.setVisibility(View.VISIBLE);
    }

    private void progressBarOff(){
        Log.d("progress bar","progressBar invisibile");

        LinearLayout meteo1 = findViewById(R.id.meteo1);
        LinearLayout meteo2 = findViewById(R.id.meteo2);
        LinearLayout meteo3 = findViewById(R.id.meteo3);

        meteo1.setVisibility(View.VISIBLE);
        meteo2.setVisibility(View.VISIBLE);
        meteo3.setVisibility(View.VISIBLE);

        progressBar.setVisibility(View.INVISIBLE);
    }

}
